# Incident Report Template
Timeline, IOCs, Root cause, Corrective actions.