# Disk Image Parser
Extracts files/timestamps from forensic images (requires pytsk3).