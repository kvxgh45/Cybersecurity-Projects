# Log Correlator
Aggregates JSON logs from multiple sources and orders by time.