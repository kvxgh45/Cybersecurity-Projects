import json, glob, datetime
# Simple correlator: merges JSON logs by timestamp bucket
events = []
for path in glob.glob("logs/*.json"):
    with open(path) as f: events += json.load(f)
events.sort(key=lambda e: e.get("ts"))
print("Total events:", len(events))
