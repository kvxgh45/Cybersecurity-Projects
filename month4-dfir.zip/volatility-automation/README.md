# Volatility Automation
Runs common Volatility plugins for quick triage.