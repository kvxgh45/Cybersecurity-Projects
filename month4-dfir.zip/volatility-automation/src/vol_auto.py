import subprocess, sys
VOL = "volatility"  # or path to vol.py/vol.exe
MEMORY = sys.argv[1] if len(sys.argv)>1 else "memdump.raw"
cmds = [
    ["-f", MEMORY, "windows.pslist"],
    ["-f", MEMORY, "windows.netstat"],
    ["-f", MEMORY, "windows.malfind"]
]
for c in cmds:
    try:
        out = subprocess.check_output([VOL]+c, text=True, timeout=120)
        print("\n###", " ".join(c), "\n", out[:2000], "...")
    except Exception as e:
        print("Error running", c, e)
